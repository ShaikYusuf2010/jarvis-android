package com.example.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.text.DateFormat
import java.util.Date
import java.util.Locale

class WakeWordService : Service(), TextToSpeech.OnInitListener {
    private val channelId = "jarvis_voice_channel"
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var isSpeaking = false
    private var stopped = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(7, buildNotification())
        tts = TextToSpeech(this, this)
        beginListening()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP_JARVIS") {
            stopped = true
            handler.removeCallbacksAndMessages(null)
            recognizer?.destroy()
            recognizer = null
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        tts?.language = Locale.US
    }

    private fun beginListening() {
        if (stopped || isSpeaking) return
        handler.postDelayed({
            if (stopped || isSpeaking) return@postDelayed
            try {
                if (recognizer == null) {
                    recognizer = SpeechRecognizer.createSpeechRecognizer(this)
                    recognizer?.setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: android.os.Bundle?) {}
                        override fun onBeginningOfSpeech() {}
                        override fun onRmsChanged(rmsdB: Float) {}
                        override fun onBufferReceived(buffer: ByteArray?) {}
                        override fun onEndOfSpeech() {}
                        override fun onError(error: Int) { scheduleRestart(900) }
                        override fun onResults(results: android.os.Bundle?) {
                            val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                                ?.firstOrNull().orEmpty()
                            handleSpeech(spoken)
                        }
                        override fun onPartialResults(partialResults: android.os.Bundle?) {}
                        override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
                    })
                }
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                }
                recognizer?.startListening(intent)
            } catch (_: Exception) {
                scheduleRestart(1500)
            }
        }, 350)
    }

    private fun handleSpeech(raw: String) {
        val text = raw.trim()
        val lower = text.lowercase(Locale.ROOT)
        if (lower.startsWith("hey jarvis") || lower.startsWith("hi jarvis")) {
            val request = text.replace(Regex("(?i)^(hey|hi) jarvis[, ]*"), "").trim()
            val answer = if (request.isBlank()) {
                "I'm listening. What can I do for you?"
            } else answerLocally(request)
            speak(answer)
        } else {
            scheduleRestart(300)
        }
    }

    private fun answerLocally(request: String): String {
        val q = request.lowercase(Locale.ROOT)
        return when {
            q.contains("time") -> "The time is " + DateFormat.getTimeInstance(DateFormat.SHORT).format(Date())
            q.contains("date") || q.contains("day") -> "Today is " + DateFormat.getDateInstance(DateFormat.FULL).format(Date())
            q.contains("hello") || q.contains("hi") -> "Hello. JARVIS is online and ready."
            q.contains("who are you") -> "I am JARVIS, your personal voice assistant."
            q.contains("stop listening") || q.contains("go offline") -> {
                handler.post { stopSelf() }
                "Okay. I am going offline."
            }
            else -> "I heard: $request. My basic voice mode is active. An AI service has not been connected yet."
        }
    }

    private fun speak(message: String) {
        if (!ttsReady) {
            scheduleRestart(500)
            return
        }
        isSpeaking = true
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
        handler.postDelayed({
            isSpeaking = false
            beginListening()
        }, (message.length * 65L).coerceIn(1800L, 6500L))
    }

    private fun scheduleRestart(delay: Long) {
        if (!stopped) handler.postDelayed({ beginListening() }, delay)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "JARVIS voice listening", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, WakeWordService::class.java).apply { action = "STOP_JARVIS" }
        val pending = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, channelId) else Notification.Builder(this)
        return builder.setContentTitle("JARVIS is listening")
            .setContentText("Say “Hey JARVIS”. Tap Stop to turn off the microphone.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(android.R.drawable.ic_media_pause, "Stop", pending)
            .setOngoing(true).build()
    }

    override fun onDestroy() {
        stopped = true
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
