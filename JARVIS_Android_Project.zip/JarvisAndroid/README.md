# JARVIS Android starter

This is a minimal Android app project for Android 8.0+ (tested target: Android 12).

## What it currently does
- Provides a JARVIS home screen.
- Starts a microphone foreground service after you tap **ENABLE “HEY JARVIS”**.
- Repeatedly uses the phone's speech-recognition service to detect phrases beginning with "Hey JARVIS".
- Speaks simple local responses for time, date, greetings, and identity.
- Shows an ongoing notification while the microphone service is active, with a Stop action.

## Important limitations
- This is a starter prototype, not a full conversational AI assistant.
- Open-ended AI answers are not connected yet; an AI provider and a securely managed API credential would be needed.
- Wake-word detection here uses the phone's speech-recognition provider, not a dedicated offline wake-word engine. It may use network services, pause, time out, or be restricted by the device/OS. It is not guaranteed to be as reliable or battery-efficient as a dedicated wake-word engine.
- Start listening while the app is visible. Android requires the microphone foreground-service notification and microphone permission. Do not expect hidden or unrestricted background recording.
- Speech-recognition availability and behavior vary by device, language, and installed speech services.

## Build without a PC using GitHub Actions
1. Sign in to GitHub in your phone browser and create a **new public or private repository** named `jarvis-android`.
2. Upload the contents of this project ZIP to the repository root (not the ZIP file itself). Make sure `.github/workflows/build-apk.yml` is included.
3. Open the repository's **Actions** tab.
4. Choose **Build JARVIS APK** and tap **Run workflow** (or wait for the first push build).
5. When it finishes, open the successful run and download the `JARVIS-debug-apk` artifact.
6. Extract the downloaded artifact ZIP on your phone, then tap `app-debug.apk` to install it. Android may ask you to allow installs from that browser/file manager.

The APK produced by this workflow is a debug APK for personal testing, not a Play Store release.
